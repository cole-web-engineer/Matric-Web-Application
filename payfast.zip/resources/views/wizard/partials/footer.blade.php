<!--

Sir Collins Eel

https://colehove.co.za

-->
<div class="wizard-footer height-wizard">
    <div class="pull-right">
        <input type='button' class='btn btn-next btn-fill btn-warning btn-wd btn-sm' name='next' value='Next' />
        <!-- <input type='submit button' class='btn btn-finish btn-fill btn-warning btn-wd btn-sm' name='submit' value='Finish' /> -->
        <button type='submit' class='btn btn-finish btn-fill btn-danger btn-wd' name='submit' id="downloadButton">Apply Now' </button>

    </div>

    <div class="pull-left">
        <input type='button' class='btn btn-previous btn-fill btn-default btn-wd btn-sm' name='previous' value='Previous' />
    </div>
    <div class="clearfix"></div>
</div>
