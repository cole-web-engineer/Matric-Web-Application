<!--

Sir collins eel

-->
<div class="wizard-navigation">

    <ul>
        <li><a href="#about" data-toggle="tab">Your Info</a></li>
        <li><a href="#account" data-toggle="tab">Subject Choice</a></li>
        <li><a href="#address" data-toggle="tab">Parent / Guardian</a></li>
        <li><a href="#uploads" data-toggle="tab">Uploads</a></li>
    </ul>

</div>