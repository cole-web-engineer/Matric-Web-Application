<!--

Sir Collins Eel

https://colehove.co.za

-->
<div class="tab-pane" id="account">

    <h4 class="info-text"> What Are You Upgrading? </h4>

    <div class="row">

        <div class="col-sm-4 ">  <!-- col-sm-offset-1 -->

            <!-- checkboxes 
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="maths"> Mathematics </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="economics"> Economics </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="geography"> Geography </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="physical_science"> Physical Science </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="engineering_science"> Engineering Science </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="industrial_orientation"> Industrial Orientation </label>
                    </div>
                </div>
            </div> -->

            <h4 class="h4">SELECT GROUP ONE SUJECTS</h4> 
            <!--Using multiple to select multiple value-->
            <select class="form-control" name = "groupOne" multiple size = 6>   
                <option value = "english">English</option> 
                <option value = "maths">Maths</option> 
                <option value = "life_science">Life Science</option> 
                <option value = "physical_science">Physical Science</option> 
                <option value = "accounts">Accounts</option> 
                <option value = "economics">Economics</option> 
            </select> 

        </div>

        <div class="col-sm-4 ">  <!-- col-sm-offset-1 -->


            <h4 class="h4">SELECT GROUP TWO SUJECTS</h4> 
            <!--Using multiple to select multiple value-->
            <select class="form-control" name="groupTwo" multiple size = 6>   
                <option value = "history">History</option> 
                <option value = "business_english">Business English</option> 
                <option value = "sake_afrikaans">Sake Business Afrikaans</option> 
                <option value = "maths_lit">Maths Literacy</option> 
                <option value = "agriculture">Agricluture</option> 
                <option value = "supervision_industry">Supervisory Industry</option> 
            </select> 

            <!-- checkboxes 
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="english"> English </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="accounts"> Accounts </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="business_studies"> Business Studies </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="history"> History(Full-time) </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="business_english"> Business English </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="sake_afrikaans"> Sake Afrikaans </label>
                    </div>
                </div>
            </div> -->

        </div>

        <div class="col-sm-4 ">  <!-- col-sm-offset-1 -->



            <h4 class="h4">SELECT GROUP THREE SUJECTS</h4> 
            <!--Using multiple to select multiple value-->
            <select class="form-control" name="groupThree" multiple size = 6>   
                <option value = "industrial_organization_planning">Industrial Org & Planning</option> 
                <option value = "afrikaans_zulu">Afrikaans / IsiZulu</option> 
                <option value = "sake_afrikaans">Sake Business Afrikaans</option> 
                <option value = "maths_lit">Maths Literacy</option> 
                <option value = "agriculture">Agricluture</option> 
                <option value = "supervision_industry">Supervisory Industry</option> 
            </select> 

            <!-- checkboxes 
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="life_science"> Life Science </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="maths_lit"> Maths Lit </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="afrikaans_zulu"> Afrikaans/IsiZulu </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="agriculture"> Agriculture </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="supervision_industry"> Supervisory Industry </label>
                    </div>
                </div>
            </div>
            <div class="form-inline">
                <div class="form-group">
                    <div class="checkbox checkbox-inline">
                        <label class="h4"> <input type="checkbox" name="industrial_organization_planning"> Industrial Org & Planning </label>
                    </div>
                </div>
            </div> -->

        </div>

    </div>
</div>