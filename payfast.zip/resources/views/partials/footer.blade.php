<!--
 * Created by PhpStorm.
 * User: Collins
 * Date: 8/12/2019
 * Time: 10:33 PM
 -->
<div class="footer">
    <div class="container">
        <strong>Made with</strong> <i class="fa fa-heart heart"></i> by <a href="http://talmaitsolutions.co.za"> <strong>Talma IT Solutions</strong> </a> <strong> C.T.H</strong>
    </div>
</div>