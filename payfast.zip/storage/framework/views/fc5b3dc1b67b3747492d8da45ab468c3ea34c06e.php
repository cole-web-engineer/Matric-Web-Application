<!--
 * Created by PhpStorm.
 * User: Collins
 * Date: 8/12/2019
 * Time: 11:10 PM
-->


    <?php $__env->startSection('content'); ?>

        <!--   Big container   -->
        <div class="container">
            <div class="row">
                <div class="col-sm-8 col-sm-offset-2">

                    <!--      Wizard container        -->
                    <div class="wizard-container">

                        <div class="card wizard-card" data-color="orange" id="wizardProfile">

                                <!--  You can switch ' data-color="orange" '  with one of the next bright colors: "blue", "green", "orange", "red"  -->

                                    <?php echo $__env->make('wizard.payment_partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                <div class="tab-content">

                                    <!-- Success Page -->

                                    <div class="row container-fluid">
                                        <p class="lead">
                                            <h3> <span><i class="fa glyphicon-fast-forward"></i></span> Payment Failed, You Can Try Again </h3>
                                        </p>
                                        <br>
                                        <p class="lead">
                                            <h4> Please Click The Button Below To Pay Application Fee <br>
                                            To Secure Your Enrolment </h4> <h2 class="h2">OR</h2>  <h4> Visit Our Selected Branch </h4>
                                        </p>
                                        <br>
                                        <p class="lead">
                                            <a href="<?php echo e(url('https://www.taalnetschools.co.za/home/pay-application-fee/')); ?>" class="btn btn-primary btn-outline-success"> Pay Now </a>
                                        </p>
                                    </div>

                                    <!-- end of content -->

                                </div>

                                <?php echo $__env->make('wizard.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                    </div> <!-- wizard container -->
                </div>
            </div> <!-- end row -->
        </div> <!--  big container -->

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>