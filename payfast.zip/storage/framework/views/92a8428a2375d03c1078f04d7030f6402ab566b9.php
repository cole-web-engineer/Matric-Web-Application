<!--
 * Created by PhpStorm.
 * User: Collins
 * Date: 8/13/2019
 * Time: 5:42 PM
 -->
<div class="wizard-header">
    <h3>
        <b>TAAL-NET MATRIC</b> REWRITE CENTRE <br>
        <hr>
        <small> <strong>Application Recieved !!!</strong> - <strong>Pay Registration Fee</strong> </small>
        <hr>
    </h3>
</div>
